<section class="rooms section--blockbg section--nopb">
    <div class="block"></div>
    <div class="container">
        <div class="rooms_header d-sm-flex justify-content-between align-items-center">
            <h2 class="rooms_header-title" data-aos="fade-right">Hostel rooms</h2>
            <div class="wrapper" data-aos="fade-left">
                <a class="btn theme-element theme-element--light" href="rooms.html">View all rooms</a>
            </div>
        </div>
        <ul class="rooms_list d-md-flex flex-wrap">
            <li class="rooms_list-item col-md-6 col-xl-4" data-order="1" data-aos="fade-up">
                <div class="item-wrapper d-md-flex flex-column">
                    <div class="media">
                        <picture>
                            <!-- <source data-srcset="/assets/images/placeholder.jpg" srcset="/assets/images/placeholder.jpg" /> -->
                            <img class="lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                        </picture>
                        <span class="media_label media_label--pricing">
                            <span class="price h4">$18</span>
                            / 1 night
                        </span>
                    </div>
                    <div class="main d-md-flex flex-column justify-content-between flex-grow-1">
                        <a class="main_title h4" href="room.html" data-shave="true">Bed in 6-Bed Room with Shared Bathroom</a>
                        <div class="main_amenities">
                            <span class="main_amenities-item d-inline-flex align-items-center">
                                <i class="icon-user icon"></i>
                                2 Sleeps
                            </span>
                            <span class="main_amenities-item d-inline-flex align-items-center">
                                <i class="icon-bunk_bed icon"></i>
                                1 bunk bed
                            </span>
                        </div>
                        <a class="link link--arrow d-inline-flex align-items-center" href="#">
                            See availability
                            <i class="icon-arrow_right icon"></i>
                        </a>
                    </div>
                </div>
            </li>
            <li class="rooms_list-item col-md-6 col-xl-4" data-order="2" data-aos="fade-up" data-aos-delay="50">
                <div class="item-wrapper d-md-flex flex-column">
                    <div class="media">
                        <picture>
                            <!-- <source data-srcset="/assets/images/placeholder.jpg" srcset="/assets/images/placeholder.jpg" /> -->
                            <img class="lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                        </picture>
                        <span class="media_label media_label--pricing">
                            <span class="price h4">$35</span>
                            / 1 night
                        </span>
                    </div>
                    <div class="main d-md-flex flex-column justify-content-between flex-grow-1">
                        <a class="main_title h4" href="room.html" data-shave="true">Double Room with Private Bathroom</a>
                        <div class="main_amenities">
                            <span class="main_amenities-item d-inline-flex align-items-center">
                                <i class="icon-user icon"></i>
                                2 Sleeps
                            </span>
                            <span class="main_amenities-item d-inline-flex align-items-center">
                                <i class="icon-twin_bed icon"></i>
                                2 twin beds
                            </span>
                        </div>
                        <a class="link link--arrow d-inline-flex align-items-center" href="#">
                            See availability
                            <i class="icon-arrow_right icon"></i>
                        </a>
                    </div>
                </div>
            </li>
            <li class="rooms_list-item col-md-6 col-xl-4" data-order="3" data-aos="fade-up" data-aos-delay="100">
                <div class="card accent">
                    <h3 class="title">Stay Longer, Save More</h3>
                    <p class="text">It's simple: the longer you stay, the more you save!</p>
                    <div class="content">
                        <p class="text">Save up to <b>30%</b> on daily rate for stays longer than 14 nights</p>
                        <p class="text">Save up to <b>20%</b> off the nightly rate on stays between 7-14 nights</p>
                    </div>
                    <a class="btn theme-element theme-element--light" href="rooms.html">Choose room</a>
                </div>
            </li>
        </ul>
    </div>
</section>