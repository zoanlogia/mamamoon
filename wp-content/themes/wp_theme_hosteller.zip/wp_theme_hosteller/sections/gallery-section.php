<section class="gallery section">
    <div class="container">
        <div class="gallery_header d-sm-flex justify-content-between align-items-center">
            <h2 class="gallery_header-title">Photos of our rooms</h2>
            <div class="wrapper">
                <a class="btn theme-element theme-element--light" href="gallery.html">View all photos</a>
            </div>
        </div>
        <div class="gallery_grid d-grid">
            <div class="gallery_grid-item gallery_grid-item--left" data-aos="zoom-in">
                <a href="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" data-caption="Image caption" data-role="gallery-link">
                    <picture>
                        <!-- <source data-srcset="../assets/images/placeholder.jpg" srcset="../assets/images/placeholder.jpg" /> -->
                        <img class="gallery_grid-item_img lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                    </picture>
                    <div class="overlay d-flex align-items-center justify-content-center">
                        <div class="overlay_focus">
                            <svg width="105" height="106" viewBox="0 0 105 106" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M103.514 28.944C102.693 28.944 102.028 28.2795 102.028 27.4598V3.712H78.2507C77.43 3.712 76.7646 3.04749 76.7646 2.22777C76.7646 1.40805 77.43 0.74353 78.2507 0.74353H103.514C104.335 0.74353 105 1.40805 105 2.22777V27.4598C105 28.2795 104.335 28.944 103.514 28.944Z" fill="currentColor" />
                                <path d="M26.7492 105.614H1.48607C0.665335 105.614 0 104.95 0 104.13V78.8978C0 78.0781 0.665335 77.4136 1.48607 77.4136C2.3068 77.4136 2.97214 78.0781 2.97214 78.8978V102.646H26.7492C27.57 102.646 28.2353 103.31 28.2353 104.13C28.2353 104.95 27.57 105.614 26.7492 105.614Z" fill="currentColor" />
                                <path d="M1.48607 28.944C0.665335 28.944 0 28.2795 0 27.4598V2.22777C0 1.40805 0.665335 0.74353 1.48607 0.74353H26.7492C27.57 0.74353 28.2353 1.40805 28.2353 2.22777C28.2353 3.04749 27.57 3.712 26.7492 3.712H2.97214V27.4598C2.97214 28.2795 2.3068 28.944 1.48607 28.944Z" fill="currentColor" />
                                <path d="M103.514 105.614H78.2507C77.43 105.614 76.7646 104.95 76.7646 104.13C76.7646 103.31 77.43 102.646 78.2507 102.646H102.028V78.8978C102.028 78.0781 102.693 77.4136 103.514 77.4136C104.335 77.4136 105 78.0781 105 78.8978V104.13C105 104.95 104.335 105.614 103.514 105.614Z" fill="currentColor" />
                            </svg>
                        </div>
                    </div>
                </a>
            </div>
            <div class="gallery_grid-item" data-aos="zoom-in">
                <a href="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" data-caption="Image caption" data-role="gallery-link">
                    <picture>
                        <!-- <source data-srcset="../assets/images/placeholder.jpg" srcset="../assets/images/placeholder.jpg" /> -->
                        <img class="gallery_grid-item_img lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                    </picture>
                    <div class="overlay d-flex align-items-center justify-content-center">
                        <div class="overlay_focus">
                            <svg width="105" height="106" viewBox="0 0 105 106" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M103.514 28.944C102.693 28.944 102.028 28.2795 102.028 27.4598V3.712H78.2507C77.43 3.712 76.7646 3.04749 76.7646 2.22777C76.7646 1.40805 77.43 0.74353 78.2507 0.74353H103.514C104.335 0.74353 105 1.40805 105 2.22777V27.4598C105 28.2795 104.335 28.944 103.514 28.944Z" fill="currentColor" />
                                <path d="M26.7492 105.614H1.48607C0.665335 105.614 0 104.95 0 104.13V78.8978C0 78.0781 0.665335 77.4136 1.48607 77.4136C2.3068 77.4136 2.97214 78.0781 2.97214 78.8978V102.646H26.7492C27.57 102.646 28.2353 103.31 28.2353 104.13C28.2353 104.95 27.57 105.614 26.7492 105.614Z" fill="currentColor" />
                                <path d="M1.48607 28.944C0.665335 28.944 0 28.2795 0 27.4598V2.22777C0 1.40805 0.665335 0.74353 1.48607 0.74353H26.7492C27.57 0.74353 28.2353 1.40805 28.2353 2.22777C28.2353 3.04749 27.57 3.712 26.7492 3.712H2.97214V27.4598C2.97214 28.2795 2.3068 28.944 1.48607 28.944Z" fill="currentColor" />
                                <path d="M103.514 105.614H78.2507C77.43 105.614 76.7646 104.95 76.7646 104.13C76.7646 103.31 77.43 102.646 78.2507 102.646H102.028V78.8978C102.028 78.0781 102.693 77.4136 103.514 77.4136C104.335 77.4136 105 78.0781 105 78.8978V104.13C105 104.95 104.335 105.614 103.514 105.614Z" fill="currentColor" />
                            </svg>
                        </div>
                    </div>
                </a>
            </div>
            <div class="gallery_grid-item gallery_grid-item--right" data-aos="zoom-in">
                <a href="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" data-caption="Image caption" data-role="gallery-link">
                    <picture>
                        <!-- <source data-srcset="../assets/images/placeholder.jpg" srcset="../assets/images/placeholder.jpg" /> -->
                        <img class="gallery_grid-item_img lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                    </picture>
                    <div class="overlay d-flex align-items-center justify-content-center">
                        <div class="overlay_focus">
                            <svg width="105" height="106" viewBox="0 0 105 106" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M103.514 28.944C102.693 28.944 102.028 28.2795 102.028 27.4598V3.712H78.2507C77.43 3.712 76.7646 3.04749 76.7646 2.22777C76.7646 1.40805 77.43 0.74353 78.2507 0.74353H103.514C104.335 0.74353 105 1.40805 105 2.22777V27.4598C105 28.2795 104.335 28.944 103.514 28.944Z" fill="currentColor" />
                                <path d="M26.7492 105.614H1.48607C0.665335 105.614 0 104.95 0 104.13V78.8978C0 78.0781 0.665335 77.4136 1.48607 77.4136C2.3068 77.4136 2.97214 78.0781 2.97214 78.8978V102.646H26.7492C27.57 102.646 28.2353 103.31 28.2353 104.13C28.2353 104.95 27.57 105.614 26.7492 105.614Z" fill="currentColor" />
                                <path d="M1.48607 28.944C0.665335 28.944 0 28.2795 0 27.4598V2.22777C0 1.40805 0.665335 0.74353 1.48607 0.74353H26.7492C27.57 0.74353 28.2353 1.40805 28.2353 2.22777C28.2353 3.04749 27.57 3.712 26.7492 3.712H2.97214V27.4598C2.97214 28.2795 2.3068 28.944 1.48607 28.944Z" fill="currentColor" />
                                <path d="M103.514 105.614H78.2507C77.43 105.614 76.7646 104.95 76.7646 104.13C76.7646 103.31 77.43 102.646 78.2507 102.646H102.028V78.8978C102.028 78.0781 102.693 77.4136 103.514 77.4136C104.335 77.4136 105 78.0781 105 78.8978V104.13C105 104.95 104.335 105.614 103.514 105.614Z" fill="currentColor" />
                            </svg>
                        </div>
                    </div>
                </a>
            </div>
            <div class="gallery_grid-item" data-aos="zoom-in">
                <a href="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" data-caption="Image caption" data-role="gallery-link">
                    <picture>
                        <!-- <source data-srcset="../assets/images/placeholder.jpg" srcset="../assets/images/placeholder.jpg" /> -->
                        <img class="gallery_grid-item_img lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                    </picture>
                    <div class="overlay d-flex align-items-center justify-content-center">
                        <div class="overlay_focus">
                            <svg width="105" height="106" viewBox="0 0 105 106" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M103.514 28.944C102.693 28.944 102.028 28.2795 102.028 27.4598V3.712H78.2507C77.43 3.712 76.7646 3.04749 76.7646 2.22777C76.7646 1.40805 77.43 0.74353 78.2507 0.74353H103.514C104.335 0.74353 105 1.40805 105 2.22777V27.4598C105 28.2795 104.335 28.944 103.514 28.944Z" fill="currentColor" />
                                <path d="M26.7492 105.614H1.48607C0.665335 105.614 0 104.95 0 104.13V78.8978C0 78.0781 0.665335 77.4136 1.48607 77.4136C2.3068 77.4136 2.97214 78.0781 2.97214 78.8978V102.646H26.7492C27.57 102.646 28.2353 103.31 28.2353 104.13C28.2353 104.95 27.57 105.614 26.7492 105.614Z" fill="currentColor" />
                                <path d="M1.48607 28.944C0.665335 28.944 0 28.2795 0 27.4598V2.22777C0 1.40805 0.665335 0.74353 1.48607 0.74353H26.7492C27.57 0.74353 28.2353 1.40805 28.2353 2.22777C28.2353 3.04749 27.57 3.712 26.7492 3.712H2.97214V27.4598C2.97214 28.2795 2.3068 28.944 1.48607 28.944Z" fill="currentColor" />
                                <path d="M103.514 105.614H78.2507C77.43 105.614 76.7646 104.95 76.7646 104.13C76.7646 103.31 77.43 102.646 78.2507 102.646H102.028V78.8978C102.028 78.0781 102.693 77.4136 103.514 77.4136C104.335 77.4136 105 78.0781 105 78.8978V104.13C105 104.95 104.335 105.614 103.514 105.614Z" fill="currentColor" />
                            </svg>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>