<section class="latest section section--blockbg">
    <div class="block"></div>
    <div class="container">
        <div class="latest_header d-sm-flex justify-content-between align-items-center">
            <h2 class="latest_header-title" data-aos="fade-right">Hosteller news</h2>
            <div class="wrapper" data-aos="fade-left">
                <a class="btn theme-element theme-element--light" href="news.html">View all news</a>
            </div>
        </div>
        <ul class="latest_list d-md-flex flex-wrap">
            <li class="latest_list-item col-md-6 col-xl-4" data-order="1" data-aos="fade-up">
                <div class="item-wrapper d-md-flex flex-column">
                    <div class="media">
                        <picture>
                            <!-- <source data-srcset="/assets/images/placeholder.jpg" srcset="/assets/images/placeholder.jpg" /> -->
                            <img class="lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                        </picture>
                        <span class="media_label media_label--left"> Travel </span>
                    </div>
                    <div class="main d-md-flex flex-column justify-content-between flex-grow-1">
                        <a class="main_title h4" href="#" data-shave="true">How to cure wanderlust without leaving your home</a>
                        <p class="main_preview">
                            Ultrices gravida dictum fusce ut placer orci nulla pellentesque. Senect et netus et malesuada
                        </p>
                        <div class="main_metadata">
                            <span class="main_metadata-item d-inline-flex align-items-center">
                                <i class="icon-calendar icon"></i>
                                June 16, 2021
                            </span>
                            <span class="main_metadata-item d-inline-flex align-items-center">
                                <i class="icon-eye icon"></i>
                                <span class="number">120</span>
                                <span class="text">views</span>
                            </span>
                        </div>
                    </div>
                </div>
            </li>
            <li class="latest_list-item col-md-6 col-xl-4" data-order="2" data-aos="fade-up" data-aos-delay="50">
                <div class="item-wrapper d-md-flex flex-column">
                    <div class="media">
                        <picture>
                            <!-- <source data-srcset="/assets/images/placeholder.jpg" srcset="/assets/images/placeholder.jpg" /> -->
                            <img class="lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                        </picture>
                        <span class="media_label media_label--left"> Tourist Guide </span>
                    </div>
                    <div class="main d-md-flex flex-column justify-content-between flex-grow-1">
                        <a class="main_title h4" href="#" data-shave="true">Yoga Hostels to soothe your mind and nomadic soul</a>
                        <p class="main_preview">
                            Ultrices gravida dictum fusce ut placer orci nulla pellentesque. Senect et netus et malesuada
                        </p>
                        <div class="main_metadata">
                            <span class="main_metadata-item d-inline-flex align-items-center">
                                <i class="icon-calendar icon"></i>
                                June 16, 2021
                            </span>
                            <span class="main_metadata-item d-inline-flex align-items-center">
                                <i class="icon-eye icon"></i>
                                <span class="number">120</span>
                                <span class="text">views</span>
                            </span>
                        </div>
                    </div>
                </div>
            </li>
            <li class="latest_list-item col-md-6 col-xl-4" data-order="3" data-aos="fade-up" data-aos-delay="100">
                <div class="item-wrapper d-md-flex flex-column">
                    <div class="media">
                        <picture>
                            <!-- <source data-srcset="/assets/images/placeholder.jpg" srcset="/assets/images/placeholder.jpg" /> -->
                            <img class="lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
                        </picture>
                        <span class="media_label media_label--left"> Communication </span>
                    </div>
                    <div class="main d-md-flex flex-column justify-content-between flex-grow-1">
                        <a class="main_title h4" href="#" data-shave="true">What happens when you travel with strangers?</a>
                        <p class="main_preview">
                            Euismod quis viverra nibh cras pulvinar mattis nunc. Leo duis ut diam quam. Sed velit dignissim
                        </p>
                        <div class="main_metadata">
                            <span class="main_metadata-item d-inline-flex align-items-center">
                                <i class="icon-calendar icon"></i>
                                June 16, 2021
                            </span>
                            <span class="main_metadata-item d-inline-flex align-items-center">
                                <i class="icon-eye icon"></i>
                                <span class="number">120</span>
                                <span class="text">views</span>
                            </span>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</section>