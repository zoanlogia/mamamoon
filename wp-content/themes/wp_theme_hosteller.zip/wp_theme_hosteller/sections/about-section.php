<section class="about section">
    <div class="container container--about d-xl-flex align-items-center">
        <div class="about_main">
            <h2 class="about_main-header" data-aos="fade-up">We have everything you need</h2>
            <p class="about_main-text" data-aos="fade-up">
                Posuere morbi leo urna molestie at elementum eu facilisis sed. Diam phasellus vestibulum lorem sed risus
                ultricies tristique
            </p>
            <ul class="about_main-list d-sm-flex flex-wrap">
                <li class="about_main-list_item d-flex flex-column flex-sm-row align-items-center" data-aos="fade-up" data-order="1">
                    <span class="icon">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 18.8178L6.08615 20C20.1515 8.74369 40.8485 8.74369 54.9138 20L56 18.8178C41.3088 7.06075 19.6912 7.06075 5 18.8178Z" fill="currentColor" />
                            <path d="M11 27.8499L12.212 29C22.595 19.1685 39.4049 19.1685 49.788 29L51 27.8499C39.9476 17.3834 22.0525 17.3834 11 27.8499Z" fill="currentColor" />
                            <path d="M18 36.5799L19.263 38C25.1969 31.3432 34.8031 31.3432 40.737 38L42 36.5799C35.3681 29.14 24.6319 29.14 18 36.5799Z" fill="currentColor" />
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M27.3176 43.3159C29.0767 41.5614 31.9234 41.5614 33.6824 43.3159C35.4392 45.0737 35.4392 47.9232 33.6824 49.6812C31.9253 51.4393 29.076 51.4396 27.3184 49.682C25.5608 47.9243 25.5605 45.0741 27.3176 43.3159ZM28.5906 48.4085C29.645 49.4633 31.3553 49.4639 32.4105 48.4098C33.4632 47.354 33.4632 45.646 32.4105 44.5902C31.3558 43.5366 29.6465 43.5366 28.5918 44.5902C27.5366 45.6442 27.536 47.3537 28.5906 48.4085Z" fill="currentColor" />
                        </svg>
                    </span>
                    <p class="text">Free available high speed WiFi</p>
                </li>
                <li class="about_main-list_item d-flex flex-column flex-sm-row align-items-center" data-order="2" data-aos="fade-up" data-aos-delay="50">
                    <span class="icon">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M13 21.6667C13 12.4769 20.8507 5 30.5 5C40.1493 5 48 12.4769 48 21.6666C48 24.4254 47.2758 27.1608 45.9043 29.5788L31.457 54.4629C31.2647 54.7945 30.8984 55 30.5 55C30.1016 55 29.7353 54.7945 29.543 54.4629L15.101 29.587C13.7242 27.1608 13 24.4255 13 21.6667ZM30.5 51.8059L43.9849 28.5789C45.1791 26.4742 45.8124 24.0806 45.8124 21.6667C45.8124 13.6254 38.9434 7.0834 30.5 7.0834C22.0566 7.0834 15.1876 13.6253 15.1876 21.6667C15.1876 24.0807 15.8209 26.4742 17.0204 28.5881L30.5 51.8059Z" fill="currentColor" />
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M22 21.1764C22 16.5815 25.8132 12.8431 30.5 12.8431C35.1868 12.8431 39 16.5816 39 21.1765C39 25.7714 35.1868 29.5098 30.5 29.5098C25.8132 29.5098 22 25.7714 22 21.1764ZM24.125 21.1765C24.125 24.623 26.9846 27.4265 30.5 27.4265C34.0154 27.4265 36.875 24.6229 36.875 21.1765C36.875 17.73 34.0154 14.9265 30.5 14.9265C26.9846 14.9265 24.125 17.73 24.125 21.1765Z" fill="currentColor" />
                        </svg>
                    </span>
                    <p class="text">Сonvenient location in the center</p>
                </li>
                <li class="about_main-list_item d-flex flex-column flex-sm-row align-items-center" data-order="3" data-aos="fade-up" data-aos-delay="100">
                    <span class="icon">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M51.0582 15.7004H39.1938V13.5973C39.1941 12.907 38.9272 12.2452 38.4523 11.7585C37.9846 11.2768 37.3517 11.0043 36.6905 11H23.3095C22.6661 11.0003 22.0473 11.2554 21.5812 11.7125L21.531 11.7643C21.0561 12.251 20.7892 12.9128 20.7895 13.6031V15.7004H8.94179C6.7674 15.7068 5.00613 17.522 5 19.763V44.9374C5.00613 47.1784 6.7674 48.9937 8.94179 49V48.9943H51.0582C53.2305 48.9879 54.9908 47.1763 55 44.9374V19.763C54.9939 17.522 53.2326 15.7068 51.0582 15.7004ZM22.4286 13.5973C22.4296 13.3509 22.5259 13.1152 22.6963 12.9422L22.7241 12.9135C22.8846 12.7628 23.0925 12.677 23.3095 12.6722H36.6905C36.9287 12.6717 37.1574 12.7688 37.326 12.9422C37.4964 13.1152 37.5927 13.3509 37.5937 13.5973V15.6947H22.4286V13.5973ZM8.94179 47.3221H11.5065V17.3554H8.94179C7.65681 17.3617 6.61937 18.4387 6.62244 19.763V44.9374C6.63163 46.2527 7.66559 47.3158 8.94179 47.3221ZM16.3403 47.3221H13.1289L13.1345 35.7549H16.3403V47.3221ZM13.1289 34.031H16.3403V30.5832H13.1345L13.1289 34.031ZM16.3403 28.9341H13.1289L13.1345 17.3669H16.3403V28.9341ZM17.9628 47.3221H42.0372V17.3669H17.9683L17.9628 47.3221ZM46.8711 47.3221H43.6597V35.7434H46.8711V47.3221ZM43.6597 34.0195H46.8711V30.5718H43.6597V34.0195ZM46.8711 28.9341H43.6597V17.3554H46.8711V28.9341ZM51.0582 47.3278C52.3366 47.3215 53.3714 46.255 53.3776 44.9374V19.7458C53.3714 18.4282 52.3366 17.3617 51.0582 17.3554H48.4935V47.3278H51.0582Z" fill="currentColor" />
                        </svg>
                    </span>
                    <p class="text">Free storage of luggage of any size</p>
                </li>
                <li class="about_main-list_item d-flex flex-column flex-sm-row align-items-center" data-order="4" data-aos="fade-up" data-aos-delay="150">
                    <span class="icon">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M23.8125 17.6466H32.3944C36.9672 17.6466 40.6875 21.3669 40.6875 25.9395V26.2285C40.6875 30.8012 36.9672 34.5215 32.3944 34.5215H26.625V42.3535H23.8125V17.6466ZM32.3944 31.7091C35.4164 31.7091 37.875 29.2505 37.875 26.2286V25.9396C37.875 22.9177 35.4164 20.4591 32.3944 20.4591H26.625V31.7091H32.3944Z" fill="currentColor" />
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M30 6C36.4106 6 42.4375 8.49638 46.9706 13.0294C51.5035 17.5625 54 23.5895 54 30C54 36.4105 51.5035 42.4375 46.9706 46.9706C42.4375 51.5036 36.4106 54 30 54C23.5894 54 17.5625 51.5035 13.0295 46.9705C8.49647 42.4375 6 36.4105 6 30C6 23.5895 8.49647 17.5625 13.0294 13.0294C17.5625 8.49638 23.5894 6 30 6ZM30 51.1875C35.6593 51.1875 40.98 48.9836 44.9819 44.9819C48.9836 40.98 51.1875 35.6593 51.1875 30C51.1875 24.3407 48.9836 19.02 44.9819 15.0181C40.98 11.0164 35.6593 8.8125 30 8.8125C24.3406 8.8125 19.02 11.0164 15.0182 15.0181C11.0164 19.02 8.8125 24.3407 8.8125 30C8.8125 35.6593 11.0164 40.98 15.0182 44.9818C19.02 48.9836 24.3406 51.1875 30 51.1875Z" fill="currentColor" />
                        </svg>
                    </span>
                    <p class="text">Parking place allocated to you</p>
                </li>
            </ul>
            <div class="about_main-action d-flex flex-column-reverse flex-sm-row align-items-center">
                <div class="wrapper" data-aos="fade-left">
                    <a class="about_main-action_item btn theme-element theme-element--accent" href="rooms.html">Book now</a>
                </div>
                <div class="wrapper" data-aos="fade-left" data-aos-delay="50">
                    <a class="about_main-action_item link link--arrow" href="about.html">
                        More about <i class="icon-arrow_right icon"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="about_media" data-aos="zoom-in">
            <picture>
                <!-- <source data-srcset="/assets/images/placeholder.jpg" srcset="/assets/images/placeholder.jpg" /> -->
                <img class="lazy" data-src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" src="<?php echo get_template_directory_uri() . '/assets/images/placeholder.jpg' ?>" alt="media" />
            </picture>
            <a class="video-play d-inline-flex align-items-center justify-content-center" href="#">
                <i class="icon-play icon"></i>
            </a>
        </div>
    </div>
</section>