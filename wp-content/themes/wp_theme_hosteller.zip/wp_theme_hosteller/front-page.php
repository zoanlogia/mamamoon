<?php get_header(); ?>
<main>
    <?php
    include_once 'sections/hero-section.php';
    include_once 'sections/rooms-section.php';
    include_once 'sections/about-section.php';
    include_once 'sections/rating-section.php';
    include_once 'sections/reviews-section.php';
    include_once 'sections/promo-section.php';
    include_once 'sections/gallery-section.php';
    include_once 'sections/news-section.php';
    include_once 'sections/contact-section.php';
    ?>
</main>

<!-- homepage content end -->
<?php get_footer(); ?>