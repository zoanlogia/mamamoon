<div class="video d-flex align-items-center justify-content-center">
    <div class="container">
        <div class="video_frame d-flex align-items-center justify-content-center">
            <i class="icon-close video_frame-close"></i>
            <div id="player"></div>
        </div>
    </div>
</div>